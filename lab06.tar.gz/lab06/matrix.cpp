#include <iostream>
#include <fstream> // read/write files
#include <iomanip> // io manipulation

static const int max_size = 100;

// prototype functions
void readFile(int matrix1[max_size][max_size], int matrix2[max_size][max_size], int &size, const char* filename);
void printMatrix(const int matrix[max_size][max_size], int size);
void matrixSum(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size);
void matrixProd(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size);
void matrixDiff(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size);

int main() {
    int size;
    // since they are square matrices, they will have the same dimensions
    int matrixA[max_size][max_size];
    int matrixB[max_size][max_size];
    int result[max_size][max_size];

    // reads file and stores value into respective matrix
    readFile(matrixA, matrixB, size, "matrix_input.txt");

    std::cout << "Jenna Luong" << std::endl; // std::endl creates a new line
    std::cout << "Lab #6: Matrix manipulation\n" << std::endl;

    // prints matrix A
    std::cout << "Matrix A:" << std::endl;
    printMatrix(matrixA, size);
    std::cout << std::endl; // prints new line

    // prints matrix B
    std::cout << "Matrix B:" << std::endl;
    printMatrix(matrixB, size);
    std::cout << std::endl;

    // add matrix a and b
    std::cout << "Matrix Sum (A + B):" << std::endl;
    matrixSum(matrixA, matrixB, result, size);
    printMatrix(result, size);
    std::cout << std::endl;
    
    // multiply matrix a and b
    std::cout << "Matrix Product (A * B)" << std::endl;
    matrixProd(matrixA, matrixB, result, size);
    
    printMatrix(result, size);
    std::cout << std::endl;

    // subtract matrix b and a
    std::cout << "Matrix Difference (A - B)" << std::endl;
    matrixDiff(matrixA, matrixB, result, size);
    printMatrix(result, size);
    std::cout << std::endl;
    
    return 0;
}

// readsFile func. takes in a matrix & size to create matrix and the filename
void readFile(int matrix1[max_size][max_size], int matrix2[max_size][max_size], int &size, const char* filename) {
    std::ifstream file;
    file.open(filename); // open file to read
    if (file.is_open()) {
        file >> size; // extracts the first integer from the file and stores into size. we know that the size is the first integer in the file.
        // now to get the matrix values. we want the condition to be i < size bc the number of rows & columns can't exceed size
        // martix A. for loop for row
        for (int i = 0; i < size; i++) {
            // for loop for column
            for (int j = 0; j < size; j++) {
                file >> matrix1[i][j]; // stores value into row i and col j of matrix
                
            }
        }
        // matrix B. for loop for row
        for (int i = 0; i < size; i++) {
            // for loop for column
            for (int j = 0; j < size; j++) {
                file >> matrix2[i][j]; // stores value into row i and col j of matrix
                
            }
        }
        file.close(); // close file
    }
    else {
        std::cerr << "File Error" << std::endl; // prints error
        exit(1);
    }
}

// printMatrix func. takes in a constant matrix and its size to print the matrix
void printMatrix(const int matrix[max_size][max_size], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            std::cout << std::left << std::setw(3) << matrix[i][j] << " "; // left centers matrix values and prints value then prints " " to add the spaces between the columns
        }
        std::cout << std::endl; // prints new line after a row has been completed
    }
}

// matrixSum func. takes in 2 constant matrices (A and B), a result matrix and size.
void matrixSum(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            result_matrix[i][j] = matrix1[i][j] + matrix2[i][j]; // result_matrix is now the sum of matrix1 and matrix2
        }
    }
}

// matrixProd func. takes in 2 constant matrices (A and B), a result matrix and size.
void matrixProd(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            result_matrix[i][j] = 0;
            // we need another value bc we need to multiply each element of the row and column
            for (int k = 0; k < size; k++) {
                result_matrix[i][j] += (matrix1[i][k] * matrix2[k][j]); // adds up each product and makes that sum the result_matrix
            } 
        }
    }
}

// matrixDiff func. takes in 2 constant matrices (A and B), a result matrix and size.
void matrixDiff(const int matrix1[max_size][max_size], const int matrix2[max_size][max_size], int result_matrix[max_size][max_size], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            result_matrix[i][j] = matrix1[i][j] - matrix2[i][j]; // result_matrix is now the difference of matrix1 and matrix2
        }
    }
}